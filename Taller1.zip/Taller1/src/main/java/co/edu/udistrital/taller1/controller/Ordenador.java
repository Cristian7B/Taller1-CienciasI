package co.edu.udistrital.taller1.controller;

import java.util.ArrayList;

import co.edu.udistrital.taller1.model.Candidato;
import co.edu.udistrital.taller1.model.Corrupcion;
import co.edu.udistrital.taller1.model.HorasClase;
import co.edu.udistrital.taller1.model.Marchas;
import co.edu.udistrital.taller1.model.Prebendas;
import co.edu.udistrital.taller1.model.Sobornos;

public class Ordenador {

    private long comparaciones = 0;
    private long intercambios = 0;


    public Ordenador() {}

    public void resetContadores() {
        this.comparaciones = 0;
        this.intercambios = 0;
    }

    public void burbujaCorrupcion(ArrayList<Candidato> candidatos){

        for (Candidato candidato : candidatos) {
            ArrayList<Corrupcion> lista = candidato.getCorrupcion(); // ejemplo para edad
            int n = lista.size();

            for (int i = 0; i < n - 1; i++) {
                for (int j = 0; j < n - i - 1; j++) {
                    comparaciones++;
                    if (lista.get(j).getValor()< lista.get(j + 1).getValor()) {
                        // intercambiar
                        Corrupcion temp = lista.get(j);
                        lista.set(j, lista.get(j + 1));
                        lista.set(j + 1, temp);
                        intercambios++;
                    }
                }
            }
            
            candidato.setCorrupcion(lista); // actualizar la lista ordenada

            // Imprimir la lista ordenada
            System.out.println("Candidato ID: " + candidato.getId());
            System.out.println("Lista de Corrupción ordenada:");
            for (Corrupcion c : lista) {
                System.out.println(c);
            }
        }

        System.out.println("Comparaciones: " + comparaciones);
        System.out.println("Intercambios: " + intercambios);

    }

    public void BurbujaMarchas(ArrayList<Candidato> candidatos){
        for (Candidato candidato : candidatos) {

            ArrayList<Marchas> lista = candidato.getMarchas(); // ejemplo para edad
            int n = lista.size();

            for (int i = 0; i < n - 1; i++) {
                for (int j = 0; j < n - i - 1; j++) {
                    comparaciones++;
                    if (lista.get(j).getValor() < lista.get(j + 1).getValor()) {
                        // intercambiar
                        Marchas temp = lista.get(j);
                        lista.set(j, lista.get(j + 1));
                        lista.set(j + 1, temp);
                        intercambios++;
                    }
                }
            }
            
            candidato.setMarchas(lista); // actualizar la lista ordenada

            // Imprimir la lista ordenada
            System.out.println("Candidato ID: " + candidato.getId());
            System.out.println("Lista de marchas ordenada:");
            for (Marchas c : lista) {
                System.out.println(c);
            }
        }

        System.out.println("Comparaciones: " + comparaciones);
        System.out.println("Intercambios: " + intercambios);
    }


    public void BurbujaHorasClase(ArrayList<Candidato> candidatos){

        for (Candidato candidato : candidatos) {

            ArrayList<HorasClase> lista = candidato.getHorasClase(); // ejemplo para edad
            int n = lista.size();

            for (int i = 0; i < n - 1; i++) {
                for (int j = 0; j < n - i - 1; j++) {
                    comparaciones++;
                    if (lista.get(j).getValor() < lista.get(j + 1).getValor()) {
                        // intercambiar
                        HorasClase temp = lista.get(j);
                        lista.set(j, lista.get(j + 1));
                        lista.set(j + 1, temp);
                        intercambios++;
                    }
                }
            }
            
            candidato.setHorasClase(lista); // actualizar la lista ordenada

            // Imprimir la lista ordenada
            System.out.println("Candidato ID: " + candidato.getId());
            System.out.println("Lista de horas clase ordenada:");
            for (HorasClase c : lista) {
                System.out.println(c);
            }
        }

        System.out.println("Comparaciones: " + comparaciones);
        System.out.println("Intercambios: " + intercambios);

    }

    public void BurbujaPrebendas(ArrayList<Candidato> candidatos){

        for (Candidato candidato : candidatos) {

            ArrayList<Prebendas> lista = candidato.getPrebendas(); // ejemplo para edad
            int n = lista.size();

            for (int i = 0; i < n - 1; i++) {
                for (int j = 0; j < n - i - 1; j++) {
                    comparaciones++;
                    if (lista.get(j).getValor() < lista.get(j + 1).getValor()) {
                        // intercambiar
                        Prebendas temp = lista.get(j);
                        lista.set(j, lista.get(j + 1));
                        lista.set(j + 1, temp);
                        intercambios++;
                    }
                }
            }
            
            candidato.setPrebendas(lista); // actualizar la lista ordenada

            // Imprimir la lista ordenada
            System.out.println("Candidato ID: " + candidato.getId());
            System.out.println("Lista de prebendas ordenada:");
            for (Prebendas c : lista) {
                System.out.println(c);
            }
        }

        System.out.println("Comparaciones: " + comparaciones);
        System.out.println("Intercambios: " + intercambios);

    }


    public void BurbujaSobornos(ArrayList<Candidato> candidatos){

        for (Candidato candidato : candidatos) {

            ArrayList<Sobornos> lista = candidato.getSobornos(); // ejemplo para edad
            int n = lista.size();

            for (int i = 0; i < n - 1; i++) {
                for (int j = 0; j < n - i - 1; j++) {
                    comparaciones++;
                    if (lista.get(j).getValor() < lista.get(j + 1).getValor()) {
                        // intercambiar
                        Sobornos temp = lista.get(j);
                        lista.set(j, lista.get(j + 1));
                        lista.set(j + 1, temp);
                        intercambios++;
                    }
                }
            }
            
            candidato.setSobornos(lista);// actualizar la lista ordenada

            // Imprimir la lista ordenada
            System.out.println("Candidato ID: " + candidato.getId());
            System.out.println("Lista de Sobornos ordenada:");
            for (Sobornos c : lista) {
                System.out.println(c);
            }
        }

        System.out.println("Comparaciones: " + comparaciones);
        System.out.println("Intercambios: " + intercambios);

    }

    public void ordenarCandidatosBurbuja(ArrayList<Candidato> candidatos) {
        int n = candidatos.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                comparaciones++;
                if (candidatos.get(j).getId() > candidatos.get(j + 1).getId()) {
                    // intercambiar
                    Candidato temp = candidatos.get(j);
                    candidatos.set(j, candidatos.get(j + 1));
                    candidatos.set(j + 1, temp);
                    intercambios++;
                }
            }
        }
    }

    public void ordenarCandidatosSeleccion(ArrayList<Candidato> candidatos) {
        int n = candidatos.size();
        for (int i = 0; i < n - 1; i++) {
            int minIdx = i;
            for (int j = i + 1; j < n; j++) {
                comparaciones++;
                if (candidatos.get(j).getId() < candidatos.get(minIdx).getId()) {
                    minIdx = j;
                }
            }
            // intercambiar
            if (minIdx != i) {
                Candidato temp = candidatos.get(i);
                candidatos.set(i, candidatos.get(minIdx));
                candidatos.set(minIdx, temp);
                intercambios++;
            }
        }
    }

    public void ordenarCandidatosInsercion(ArrayList<Candidato> candidatos) {
        int n = candidatos.size();
        for (int i = 1; i < n; i++) {
            Candidato key = candidatos.get(i);
            int j = i - 1;
            while (j >= 0 && candidatos.get(j).getId() > key.getId()) {
                comparaciones++;
                candidatos.set(j + 1, candidatos.get(j));
                j--;
                intercambios++;
            }
            candidatos.set(j + 1, key);
        }
    }

    public void ordenarCandidatosMergeSort(ArrayList<Candidato> candidatos) {
        if (candidatos.size() < 2) {
            return;
        }
        int mid = candidatos.size() / 2;
        ArrayList<Candidato> left = new ArrayList<>(candidatos.subList(0, mid));
        ArrayList<Candidato> right = new ArrayList<>(candidatos.subList(mid, candidatos.size()));

        ordenarCandidatosMergeSort(left);
        ordenarCandidatosMergeSort(right);

        merge(candidatos, left, right);
    }

    private void merge(ArrayList<Candidato> candidatos, ArrayList<Candidato> left, ArrayList<Candidato> right) {
        int i = 0, j = 0, k = 0;
        while (i < left.size() && j < right.size()) {
            comparaciones++;
            if (left.get(i).getId() <= right.get(j).getId()) {
                candidatos.set(k++, left.get(i++));
            } else {
                candidatos.set(k++, right.get(j++));
            }
            intercambios++;
        }
        while (i < left.size()) {
            candidatos.set(k++, left.get(i++));
            intercambios++;
        }
        while (j < right.size()) {
            candidatos.set(k++, right.get(j++));
            intercambios++;
        }
    }

    public void ordenarCandidatosQuickSort(ArrayList<Candidato> candidatos) {
        quickSort(candidatos, 0, candidatos.size() - 1);
    }

    private void quickSort(ArrayList<Candidato> candidatos, int low, int high) {
        if (low < high) {
            int pi = partition(candidatos, low, high);
            quickSort(candidatos, low, pi - 1);
            quickSort(candidatos, pi + 1, high);
        }
    }

    private int partition(ArrayList<Candidato> candidatos, int low, int high) {
        Candidato pivot = candidatos.get(high);
        int i = (low - 1);
        for (int j = low; j < high; j++) {
            comparaciones++;
            if (candidatos.get(j).getId() <= pivot.getId()) {
                i++;
                // intercambiar
                Candidato temp = candidatos.get(i);
                candidatos.set(i, candidatos.get(j));
                candidatos.set(j, temp);
                intercambios++;
            }
        }
        // intercambiar
        Candidato temp = candidatos.get(i + 1);
        candidatos.set(i + 1, candidatos.get(high));
        candidatos.set(high, temp);
        intercambios++;
        return i + 1;
    }

    // Getters para comparaciones e intercambios
    public long getComparaciones() {
        return comparaciones;
    }
    public long getIntercambios() {
        return intercambios;
    }


}
